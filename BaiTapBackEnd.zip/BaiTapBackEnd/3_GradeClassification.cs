using System;

namespace GradeClassification
{
    class Program
    {
        static void Main(string[] args)
        {
            // Khai báo biến score để lưu điểm của sinh viên
            int score = 75; // Có thể thay đổi giá trị để kiểm tra các trường hợp khác

            // Khai báo biến grade để lưu kết quả xếp loại
            string grade;

            // Kiểm tra điểm từ 90 đến 100
            if (score >= 90 && score <= 100)
            {
                grade = "A (Xuat sac)";
            }
            // Kiểm tra điểm từ 80 đến dưới 90
            else if (score >= 80)
            {
                grade = "B (Kha)";
            }
            // Kiểm tra điểm từ 70 đến dưới 80
            else if (score >= 70)
            {
                grade = "C (Trung binh)";
            }
            // Kiểm tra điểm từ 60 đến dưới 70
            else if (score >= 60)
            {
                grade = "D (Yeu)";
            }
            // Các trường hợp còn lại (dưới 60)
            else
            {
                grade = "F (Khong đat)";
            }

            // In ra điểm và kết quả xếp loại
            Console.WriteLine($"Diem: {score}  Xep loai: {grade}");
        }
    }
}
