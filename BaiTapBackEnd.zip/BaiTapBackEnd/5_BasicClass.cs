using System;

namespace BasicClass
{
    // Lớp Student dùng để mô tả thông tin của một sinh viên
    class Student
    {
        // Thuộc tính StudentId dùng để lưu mã sinh viên
        public int StudentId;

        // Thuộc tính Name dùng để lưu tên sinh viên
        public string Name;

        // Thuộc tính GPA dùng để lưu điểm trung bình
        public double GPA;

        // Phương thức Display dùng để hiển thị thông tin sinh viên ra màn hình
        public void Display()
        {
            Console.WriteLine($"ID: {StudentId}, Name: {Name}, GPA: {GPA}");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Tạo đối tượng sinh viên thứ nhất
            Student s1 = new Student();

            // Gán giá trị cho các thuộc tính của sinh viên s1
            s1.StudentId = 1;
            s1.Name = "An";
            s1.GPA = 8.5;

            // Tạo đối tượng sinh viên thứ hai
            Student s2 = new Student();

            // Gán giá trị cho các thuộc tính của sinh viên s2
            s2.StudentId = 2;
            s2.Name = "Binh";
            s2.GPA = 7.9;

            // Gọi phương thức Display để hiển thị thông tin sinh viên
            s1.Display();
            s2.Display();
        }
    }
}
