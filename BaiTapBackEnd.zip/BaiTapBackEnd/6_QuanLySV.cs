using System;
namespace StudentManagementSystem
{
    // TODO 6.1: LOP STUDENT
    public class Student
    {
        public string StudentId { get; set; }
        public string Name { get; set; }
        public double Score { get; set; }
        public Student(string id, string name, double score)
        {
            if (string.IsNullOrWhiteSpace(id))
                throw new ArgumentException("StudentId khong duoc rong");

            if (string.IsNullOrWhiteSpace(name))
                throw new ArgumentException("Ten sinh vien khong duoc rong");

            if (score < 0 || score > 10)
                throw new ArgumentException("Diem phai tu 0 den 10");

            StudentId = id;
            Name = name;
            Score = score;
        }
        // In thong tin sinh vien
        public void Display()
        {
            Console.WriteLine("ID: " + StudentId + " | Ten: " + Name + " | Diem: " + Score);
        }
    }
    // TODO 6.2: LOP STUDENT MANAGER
    public class StudentManager
    {
        private Student[] students = new Student[50];
        private int count = 0;
        // Them sinh vien
        public void AddStudent(string id, string name, double score)
        {
            if (count >= 50)
                throw new Exception("Danh sach sinh vien da day");

            if (FindStudentById(id) != null)
                throw new Exception("ID sinh vien da ton tai");

            students[count] = new Student(id, name, score);
            count++;
        }
        // Xoa sinh vien theo ID
        public void RemoveStudent(string id)
        {
            for (int i = 0; i < count; i++)
            {
                if (students[i].StudentId == id)
                {
                    for (int j = i; j < count - 1; j++)
                    {
                        students[j] = students[j + 1];
                    }
                    students[count - 1] = null;
                    count--;
                    return;
                }
            }
            throw new Exception("Khong tim thay sinh vien");
        }
        // Cap nhat diem
        public void UpdateScore(string id, double newScore)
        {
            if (newScore < 0 || newScore > 10)
                throw new Exception("Diem phai tu 0 den 10");

            Student s = FindStudentById(id);
            if (s == null)
                throw new Exception("Khong tim thay sinh vien");

            s.Score = newScore;
        }
        // Tinh diem trung binh
        public double GetAverageScore()
        {
            if (count == 0) return 0;

            double sum = 0;
            for (int i = 0; i < count; i++)
            {
                sum += students[i].Score;
            }
            return sum / count;
        }
        // Tim diem cao nhat
        public double GetMaxScore()
        {
            if (count == 0) return 0;

            double max = students[0].Score;
            for (int i = 1; i < count; i++)
            {
                if (students[i].Score > max)
                    max = students[i].Score;
            }
            return max;
        }

        // Tim sinh vien theo ID
        public Student FindStudentById(string id)
        {
            for (int i = 0; i < count; i++)
            {
                if (students[i].StudentId == id)
                    return students[i];
            }
            return null;
        }

        // In danh sach sinh vien
        public void DisplayAllStudents()
        {
            if (count == 0)
            {
                Console.WriteLine("Danh sach sinh vien trong");
                return;
            }

            for (int i = 0; i < count; i++)
            {
                students[i].Display();
            }
        }
    }

    // TODO 6.3: MAIN PROGRAM
    class Program
    {
        static void Main(string[] args)
        {
            StudentManager manager = new StudentManager();
            bool running = true;

            while (running)
            {
                Console.WriteLine("\n========== MENU ==========");
                Console.WriteLine("1. Them sinh vien");
                Console.WriteLine("2. Xoa sinh vien");
                Console.WriteLine("3. Cap nhat diem");
                Console.WriteLine("4. In danh sach sinh vien");
                Console.WriteLine("5. Tinh diem trung binh");
                Console.WriteLine("6. Tim diem cao nhat");
                Console.WriteLine("7. Tim sinh vien theo ID");
                Console.WriteLine("0. Thoat");
                Console.WriteLine("==========================");
                Console.Write("Chon: ");

                try
                {
                    int choice = int.Parse(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:
                            Console.Write("ID: ");
                            string id = Console.ReadLine();

                            Console.Write("Ten: ");
                            string name = Console.ReadLine();

                            Console.Write("Diem: ");
                            double score = double.Parse(Console.ReadLine());

                            manager.AddStudent(id, name, score);
                            Console.WriteLine("Them sinh vien thanh cong");
                            break;

                        case 2:
                            Console.Write("Nhap ID can xoa: ");
                            manager.RemoveStudent(Console.ReadLine());
                            Console.WriteLine("Xoa sinh vien thanh cong");
                            break;

                        case 3:
                            Console.Write("Nhap ID sinh vien: ");
                            string updateId = Console.ReadLine();

                            Console.Write("Nhap diem moi: ");
                            double newScore = double.Parse(Console.ReadLine());

                            manager.UpdateScore(updateId, newScore);
                            Console.WriteLine("Cap nhat diem thanh cong");
                            break;

                        case 4:
                            manager.DisplayAllStudents();
                            break;

                        case 5:
                            Console.WriteLine("Diem trung binh: " + manager.GetAverageScore());
                            break;

                        case 6:
                            Console.WriteLine("Diem cao nhat: " + manager.GetMaxScore());
                            break;

                        case 7:
                            Console.Write("Nhap ID: ");
                            Student s = manager.FindStudentById(Console.ReadLine());
                            if (s != null)
                                s.Display();
                            else
                                Console.WriteLine("Khong tim thay sinh vien");
                            break;

                        case 0:
                            running = false;
                            break;

                        default:
                            Console.WriteLine("Lua chon khong hop le");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Loi: " + ex.Message);
                }
            }
        }
    }
}
